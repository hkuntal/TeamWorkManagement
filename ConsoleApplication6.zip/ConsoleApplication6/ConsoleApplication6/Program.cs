﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
         MailMessage myHtmlMessage; 
        SmtpClient mySmtpClient; 

        
        myHtmlMessage = new MailMessage();

        myHtmlMessage.From = new MailAddress("santosh.thakur@citiustech.com", "Santosh Thakur");
        //myHtmlMessage.To.Add("asim.bera@citiustech.com");
        //myHtmlMessage.CC.Add("uday.gadamsetty@citiustech.com");
        //myHtmlMessage.Bcc.Add("hariom.kuntal@citiustech.com");
        myHtmlMessage.To.Add("sagar.kavitake@citiustech.com");
        //myHtmlMessage.To.Add("pravin.mohite@citiustech.com");
   
        myHtmlMessage.Subject = "URGENT: Onsite Requirement";
        myHtmlMessage.Body = ReadFile();

        myHtmlMessage.Attachments.Add(AddInlineAttachment("AprilFool.jpg"));

        myHtmlMessage.Priority = System.Net.Mail.MailPriority.High;
        myHtmlMessage.IsBodyHtml = true;

        mySmtpClient = new SmtpClient("smtp.emailsrvr.com", 587);
        mySmtpClient.Credentials = new NetworkCredential("sagar.kavitake@citiustech.com", "#####");


        mySmtpClient.EnableSsl = false;

       mySmtpClient.Send(myHtmlMessage);

        
        }

        private static Attachment AddInlineAttachment(string FileName)
        {
            Attachment attchmnt = new Attachment(@"C:\Users\sagark\Documents\Visual Studio 2012\Projects\ConsoleApplication6\ConsoleApplication6\" + FileName);
            attchmnt.ContentDisposition.Inline = true;
            attchmnt.ContentId = FileName.Substring(FileName.LastIndexOf("\\") + 1).Replace(".", "");
            return attchmnt;
        }

        private static string ReadFile()
        {
            StringBuilder strContents = new StringBuilder();
        StreamReader objReader;
        objReader = new StreamReader(@"c:\users\sagark\documents\visual studio 2012\Projects\ConsoleApplication6\ConsoleApplication6\Test.htm");
        strContents.Append(objReader.ReadToEnd());
        objReader.Close();


        return strContents.ToString();
        }
    }
}
